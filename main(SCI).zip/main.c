
//defines:
#define xdc__strict //suppress typedef warnings

//includes:
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <ti/sysbios/BIOS.h>
#include <Headers/F2837xD_device.h>
#include <stdio.h>


// Function prototypes
extern void DeviceInit(void);
extern void DelayUs(Uint16);
void scia_xmit(int a);
void scia_msg(char *msg);

//Globals
volatile UInt tickCount = 0; //counter incremented by timer interrupt
volatile Bool dataReceivedFlag = FALSE;
#define BUFFER_SIZE 128
Uint16 rdata_pointA; // Used for checking the received data
char rdataA[BUFFER_SIZE];    // Received data for SCI-A
char *msg = "\r\n\n\nHello World!\0";


// Main function
Int main()
{ 

    System_printf("Enter main()\n"); // Use ROV->SysMin to view characters in circular buffer

    // Initialization:
    DeviceInit(); // Initialize processor

    // Jump to RTOS (does not return):
    BIOS_start();
    return 0;
}

void scia_xmit(int a)
{
    while (ScibRegs.SCIFFTX.bit.TXFFST != 0) {}
    ScibRegs.SCITXBUF.all = a;
}

void scia_msg(char *msg)
{
    int i;
    i = 0;

    ScibRegs.SCICTL1.bit.TXENA = 1;
    while(msg[i] != '\0')
    {
        scia_xmit(msg[i]);
        i++;
    }
    ScibRegs.SCICTL1.bit.TXENA = 0;
}


// Interrupt Service Routine for SCI receive data
void SPI_HWI(void)
{
//    rdataA[rdata_pointA]=SciaRegs.SCIRXBUF.all;
//       rdata_pointA++;
//
//           if(rdata_pointA>=BUFFER_SIZE)
//               rdata_pointA = 0;
//
//           if(rdataA[rdata_pointA-1]=='\n')
//           {
//
//            SCI_writeCharArray(SCIA_BASE, (uint16_t*)rdataA, rdata_pointA);
//            memset(rdataA,'\0',128);
//            rdata_pointA = 0;
//           }
//
//
//           PieCtrlRegs.PIEACK.all|=0x100;       // Issue PIE ack
//           Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP9);
}

Void myTikFxn(UArg arg)
{
    tickCount++; //increment the tick counter
    if(tickCount % 500 == 0) { // AW If one second has passed becomes true
        scia_msg(msg);
        GpioDataRegs.GPATOGGLE.bit.GPIO31 = 1;
    }

}

// Idle function to toggle LED based on data reception
void myIdleFxn(void)
{
   //scia_msg(msg);
   if(dataReceivedFlag == TRUE) {
       dataReceivedFlag = FALSE;
       // Toggle blue LED:
       GpioDataRegs.GPATOGGLE.bit.GPIO31 = 1;
   }
}


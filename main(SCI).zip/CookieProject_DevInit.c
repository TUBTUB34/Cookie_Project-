// Filename:            CookieProject_DeviceInit.c
//
// Description:	        Initialization code
//
// Version:             1.0
//
// Target:              TMS320F28379D
//
// Author:              Alex Weir
//
// Date:                25 October 2024

#include "Headers/F2837xD_device.h"

void InitSciGpio(void);
void InitSci(void);
void scia_fifo_init(void);
extern void DelayUs(Uint16);

void DeviceInit(void)
{

    EALLOW; // Allow access to protected registers

    // Configure D10 (blue LED)
    GpioCtrlRegs.GPAMUX2.bit.GPIO31 = 0; // Set pin as GPIO
    GpioCtrlRegs.GPADIR.bit.GPIO31 = 1;  // Set GPIO as output
    GpioDataRegs.GPASET.bit.GPIO31 = 1;  // Initialize output value to "1" (LED off)

    // Initialize SPI
    InitSciGpio();
    InitSci();
    //scia_fifo_init();

    // Initialize ADC
    //InitADCGpio();
    //InitADC();
}

void scia_fifo_init()
{
    ScibRegs.SCIFFTX.all = 0xE040;
    ScibRegs.SCIFFRX.all = 0x2044;
    ScibRegs.SCIFFCT.all = 0x0;
}

void InitSciGpio(void)
{
    EALLOW;

    // Configure GPIO19 as SCIRXDB (SCI-B Receive)
    GpioCtrlRegs.GPAGMUX2.bit.GPIO19 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO19 = 2;    // Set GPIO19 to SCIRXDB
    GpioCtrlRegs.GPADIR.bit.GPIO19 = 0;     // Set GPIO19 as input for RX
    GpioCtrlRegs.GPAQSEL2.bit.GPIO19 = 3;   // Async

    // Configure GPIO18 as SCITXDB (SCI-B Transmit)
    GpioCtrlRegs.GPAGMUX2.bit.GPIO18 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 2;    // Set GPIO18 to SCITXDB
    GpioCtrlRegs.GPADIR.bit.GPIO18 = 1;     // Set GPIO18 as output for TX
    GpioCtrlRegs.GPAQSEL2.bit.GPIO18 = 3;   // Async

    EDIS;
}

void InitSci(void)
{
    //EALLOW;

    ScibRegs.SCICTL1.bit.SWRESET = 0; // hold in reset
    ScibRegs.SCICCR.all = 0x0007;   // 1 stop bit,  No loopback
                                    // No parity,8 char bits,
                                    // async mode, idle-line protocol

    ScibRegs.SCICTL2.bit.TXINTENA = 1;
    ScibRegs.SCICTL2.bit.RXBKINTENA = 1;
    //
    // SCIA at 9600 baud
    // @LSPCLK = 50 MHz (200 MHz SYSCLK) HBAUD = 0x02 and LBAUD = 0x8B.
    // @LSPCLK = 30 MHz (120 MHz SYSCLK) HBAUD = 0x01 and LBAUD = 0x86.
    //
    ScibRegs.SCIHBAUD.all = 0x0002;
    ScibRegs.SCILBAUD.all = 0x008B;
    ScibRegs.SCICTL1.bit.SWRESET = 1; // Out of reset

    //From the C2000Ware ex

//    // Configure SCI Control Registers
//    ScibRegs.SCICTL1.bit.SWRESET = 0;  // Hold SCI-B in reset
//
//    ScibRegs.SCICCR.bit.STOPBITS = 1;
//    ScibRegs.SCICCR.bit.PARITY = 0;
//    ScibRegs.SCICCR.bit.LOOPBKENA = 0;
//    ScibRegs.SCICCR.bit.SCICHAR = 0x7;
//    ScibRegs.SCICTL1.bit.RXENA = 1;        // Enable TX and RX, internal SCICLK
//    ScibRegs.SCICTL1.bit.TXENA = 1;
//
//    ScibRegs.SCICTL2.bit.RXBKINTENA = 1;        // Enable TX/RX interrupts
//    ScibRegs.SCICTL2.bit.TXINTENA = 1;
//
//    //
//    // SCI at 9600 baud
//    // @LSPCLK = 50 MHz (200 MHz SYSCLK) HBAUD = 0x02 and LBAUD = 0x8B.
//    // @LSPCLK = 30 MHz (120 MHz SYSCLK) HBAUD = 0x01 and LBAUD = 0x86.
//    //
//    ScibRegs.SCIHBAUD.all = 0x0002;       // High byte of baud rate
//    ScibRegs.SCILBAUD.all = 0x008B;       // Low byte of baud rate
//
//    // Enable TX/RX and release from reset
//    ScibRegs.SCICTL1.bit.SWRESET = 1;

    //EDIS;
}
